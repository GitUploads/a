var myApp = angular.module("myApp",['ngRoute']);
myApp.service("dbData", function($http){
    var obj = {};
    obj.fetch = function(cb){
        $http({
            url: "http://localhost/niraj/2310/fetchCourses.php" ,
            method: "get"
        }).then(function(r){
            cb(r.data);
        }, function(e){ });
    }
    obj.search = function(uid,cb){
        $http({
            url: "http://localhost/niraj/2310/search.php" ,
            method: "get",
            params: {id: uid}
        }).then(function(r){
            cb(r.data);
        }, function(e){ });
    }
    obj.fetchStudents = function(cb){
        $http({
            url: "http://localhost/niraj/2310/fetchStudents.php" ,
            method: "get"
        }).then(function(r){
            cb(r.data);
        }, function(e){ });
    }
    obj.searchStudents = function(cb){
        $http({
            method: "get",
            url: "http://localhost/niraj/2310/searchstudents.php",
            params: {name: $routeParams.name}
        }).then(function(res){
            cb(res.data)
        }, function(){ })
    }
    return obj;
});
myApp.config(function($routeProvider){
    $routeProvider
        .when("/",{
            templateUrl: "home.html"  // College - Front Page... Lorem Ipsum
        })
        .when("/students",{
            templateUrl: "students.html", //CRUD - factory
            controller: "studController",
            controllerAs: "sc",
            resolve: {
                studentFetch : function($http){
                    return $http({
                        method: "get",
                        url: "http://localhost/niraj/2310/fetchStudents.php"
                    }).then(function(r){ 
                        return r.data;
                    }, function(e){ });
                }
            }
        })
        .when("/courses",{
            templateUrl: "courses.html", //CRUD - service
            controller: "coursesController",
            controllerAs : "cc"
        })
        .when("/courses/:id",{
            templateUrl: "searchCourse.html",
            controller: "searchCourseController",
            controllerAs: "ssc"
        })
        .when("/404", {
            templateUrl: "404.html"
        })
        .when("/studentsSearch/:name?",{
            templateUrl: "searchStudents.html",
            controller: "searchStudents",
            controllerAs: "ss"
        })
        .otherwise({
            redirectTo: '/404'
        })
});
myApp.controller("searchStudents", function(dbData,$routeParams, $http){
    var vm = this;
    if($routeParams.name == null || $routeParams.name == "undefined"){
        dbData.fetchStudents(function(data){
            vm.students = data;
        });
    }
    else if($routeParams.name != "undefined"){
        dbData.fetchStudents(function(data){
            vm.students = data;
        })
    }

});
homeController = function($scope){
    $scope.data = "Hello World";
}
studentController = function(studentFetch, $location){
    var vm = this;
    //cut 
    vm.students = studentFetch;
    vm.searchMe = function(){
        //alert("I am getting displayed " +vm.name);
        $location.url("/studentsSearch/" + vm.name)
    }
}
myApp.controller("coursesController", function($scope,dbData){
    var cc = this;
    $scope.$on("$routeChangeStart",function(event,next,previous){
        console.log(next);
        if(!confirm("Redirecting you to new page!!!: " +next)){
            event.preventDefault();
        }
    });
    $scope.visible = false;
    $scope.$on("$routeChangeStart", function(event,next,previous){
        $scope.visible = true;
    });
    $scope.$on("$routeChangeSuccess", function(event,next,previous){
        $scope.visible = false;
    });

    // var abc = function(){
    //     $scope.$on("$routeChangeStart",function(event,next,previous){
    //         console.log("$routeChangeStart Callled!!!");
    //     });
    //     $scope.$on("$locationChangeStart",function(event,next,previous){
    //         console.log("$locationChangeStart Callled!!!");
    //     });
    //     $scope.$on("$routeChangeSuccess",function(event,next,previous){
    //         console.log("$routeChangeSuccess Callled!!!");
    //     });
    //     $scope.$on("$locationChangeSuccess",function(event,next,previous){
    //         console.log("$locationChangeSuccess Callled!!!");
    //     });
    //}
    dbData.fetch(function(data){
        cc.courses = data;
    });
})
myApp.controller("myC", homeController);

myApp.controller("studController", studentController);
