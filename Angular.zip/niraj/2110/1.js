var myApp = angular.module("myMod",[]);
myApp.factory("dbConnect", function($http){
    return {
        displayMe: function(cb){
            var success = function(response){
                //$scope.stud = response.data;
                cb(response.data)
            };

            var failure = function(error){
                //$scope.error = error.data;
                cb(error.data);
            };

            $http({
                url: "http://localhost/niraj/2110/fetch.php",
                method: "get"
            }).then(success, failure);
        },
        update: function(id,fn,g,ct){
            var success = function(response){
                alert(response.data);
            }
            var failure = function(error){
                alert(error.data);
            }
        
            $http({
                url: "http://localhost/niraj/2110/update.php?id="+id+
                                    "&fn="+fn+"&g="+g+"&ct="+ct,
                method: "get"
            }).then(success, failure);
        }
    }
});

myApp.directive("myData", function(){
    return {
        restrict: "EA",
        templateUrl: "mydata.html"
    }
});
myApp.directive("myStringData", function(){
    return {
        restrict : "E",
        scope:{
            name: "="
        },
        template: "<h3>Hello {{name}}</h3>"
    }
});


myApp.controller("myC", function($scope, $http, dbConnect){
    $scope.showMe = false;

    dbConnect.displayMe(function(data){
        console.log(data);
        $scope.stud = data;
    });

    $scope.editMe = function(id, full_name, gender, city){
        $scope.id = id;
        $scope.fn = full_name;
        $scope.g = gender;
        $scope.ct = city;
        $scope.showMe = true;
    }
    $scope.updateMe = function(){
        // update();
        dbConnect.update($scope.id, $scope.fn, $scope.g, $scope.ct);
        dbConnect.displayMe(function(data){
            console.log(data);
            $scope.stud = data;
        });
        $scope.digest();
        $scope.showMe = false;
    }
});