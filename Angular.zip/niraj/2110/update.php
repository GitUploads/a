<?php

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "empinfo";

    $conn = mysqli_connect($host, $user, $pass, $db) or die("Connection failed");

    $fn = $_GET['fn'];
    $g  = $_GET['g'];
    $ct = $_GET['ct'];
    $id = $_GET['id'];

    $query = "UPDATE stud_data SET full_name = '".$fn."', gender = '".$g."', 
                        city = '".$ct."' WHERE stud_data.id = '".$id."'";
    $result = mysqli_query($conn, $query);

    echo "Record Updated Successfully";
    // $result = mysqli_query($conn, $query);
    // $data = array();
    // while($row = mysqli_fetch_assoc($result)){
    //     $data[] = $row;
    // }
    // echo json_encode($data);