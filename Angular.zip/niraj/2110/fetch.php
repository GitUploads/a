<?php

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "empinfo";

    $conn = mysqli_connect($host, $user, $pass, $db) or die("Connection failed");


    $query = "SELECT * FROM stud_data";

    $result = mysqli_query($conn, $query);
    $data = array();
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }
    echo json_encode($data);