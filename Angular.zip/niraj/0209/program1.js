var myApp = angular.module("myModule",[]);

myApp.controller("myCntrl", function($scope){
    $scope.clickMe = function(){
        $scope.Message = "I am getting displayed...";
    }
});