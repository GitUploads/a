var myApp = angular.module("MouseOver",[]);

myApp.controller("myController",function($scope){
    $scope.myFunction = function(myEvent){
        $scope.x = myEvent.pageX;
        $scope.y = myEvent.pageY;
        console.log($scope.x + ", "+$scope.y)
    }
});