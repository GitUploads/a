var myApp = angular.module("myApp",[]);

myApp.controller("myController", [ "$scope", function(d){
    var employees =[
        {name: "Niraj" , like:0 , dislike: 0},
        {name: "Jackey" , like:0 , dislike: 0},
        {name: "Mohit" , like:0 , dislike: 0},
        {name: "Sahil" , like:0 , dislike: 0},
        {name: "Kuldeep" , like:0 , dislike: 0},
        {name: "Parth^2" , like:0 , dislike: 0}
    ]
    d.employees = employees;
    d.incrementLike = function(emp){
        emp.like++;
        if(emp.dislike >0){
            emp.dislike--;
        }
    }
    d.incrementDislike = function(emp){
        emp.dislike++;
        if(emp.like > 0){
            emp.like--;
        }
    }
}]);