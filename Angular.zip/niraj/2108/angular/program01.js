var myApp = angular.module("myModule",[]);

var myC = function($scope){
    var message = "This is MCA - Atmiya Univrsity - 3rd Semester... students. ";
    $scope.msg = message;
 }

myApp.controller("myController", myC);