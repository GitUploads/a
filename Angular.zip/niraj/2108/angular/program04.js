var myApp = angular.module("myModule",[]);

var firstFunction = function($scope){
    var message1 = "How are you...";
    $scope.msg1 = message1;
 }
 
var secondFunction = function($scope){
    var message2 = "hello....";
    $scope.msg2 = message2;
}
 
myApp.controller("firstController", firstFunction);
myApp.controller("secondController", secondFunction);