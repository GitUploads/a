<?php
    $user = "root";
    $host = "localhost";
    $pass = "";
    $db = "empinfo";


    $connection = mysqli_connect($host, $user, $pass, $db);


    $query = "SELECT * FROM EMPLOYEES";

    $result = mysqli_query($connection, $query);

    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }
    echo json_encode($data);


/*
Angular Js
Web API
28,2, 11, 41, 22, 26, 31 ,38

DADV
7, 48, 10, 27,52,34

*/