var myApp = angular.module("myModule",[]);
myApp.provider("calcService", function(){
    this.$get = function(){
        var objCalc = {};
        objCalc.add = function(a,b){
            return parseInt(a)+parseInt(b);
        }
        return objCalc;
    }

});

myApp.controller("myC", function($scope, calcService){
    $scope.btn = function(a,b){
        $scope.sum = calcService.add(a,b);
    }
});