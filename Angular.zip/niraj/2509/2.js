var myApp = angular.module("myModule",[]);
myApp.provider("calcService", function(){
    var gst = {};
    this.config = function(g){
        this.gst = g;
    }
    this.$get = function(){
        var objCalc = {};
        objCalc.add = function(a,b){
            var sum = parseInt(a)+ parseInt(b); //50+50 = 100
            var pGST = sum*gst/100; // 100*.18 = 18 
            var fGST = sum + pGST; // 100 + 18 = 118
            return fGST;
            //second way
            //return (parseInt(a)+parseInt(b)) + ((parseInt(a)+parseInt(b))*gst/100;
        }
        return objCalc;
    }

});

myApp.config(["calcServiceProvider", function(calcServiceProvider){
    calcServiceProvider.config(18);
}])

myApp.controller("myC", function($scope, calcService){
    $scope.btn = function(a,b){
        $scope.sum = calcService.add(a,b);
    }
});
