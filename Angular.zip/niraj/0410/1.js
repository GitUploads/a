var myApp = angular.module("myMod",[]);
myApp.config(["myProProvider", function(myProProvider){
    myProProvider.config(18);
}]);
myApp.provider("myPro", function(){
    var abc = {};
    this.config = function(val){
        abc = val;
    }
    this.$get = ["$http",function($http){
        return {
            fetch: function($http){
                $http({
                    method: "get",
                    url: "http://localhost/niraj/1609/dbConnect.php"
                }).then(function(res){
                    $scope.data = res.data;
                }, function(){

                })
            },
            add: function(){
                return 1+2+abc;
            },
            sub: function(){
                return 2-1-abc;
            },
            mul: function(){
                return 2*1*abc;
            },
            div: function(){
                return (1/2)/abc;
            }

        }
    }]
})
myApp.controller("myC", function(myPro,$scope){
    $scope.sum = myPro.add();
    $scope.sub = myPro.sub();
    $scope.mul = myPro.mul();
    $scope.div = myPro.div();
    myPro.fetch();
});