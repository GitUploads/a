myApp.controller("searchCourseController", function($routeParams,dbData){
    this.id = $routeParams.id;
    var ssc = this;
    dbData.search(this.id, function(data){
        ssc.data = data;
    });
})