var myApp = angular.module("myMod",[]);

myApp.config(["myProProvider", function(myProProvider){
    myProProvider.config("http://10.9.2.110/niraj/0710/")
}]);
myApp.provider("myPro", function(){
    var baseUrl = {};
    this.config = function(url){
        baseUrl = url;
    }

    this.$get = function($http){
        return {
            fetch: function(sc){
                $http({
                    url: baseUrl,
                    method: "get"
                }).then(function(res){
                   sc.data = res.data;
                }, function(err){
                    sc.error = err.data;
                })
            },
            delete: function(sc){
                $http({
                    url: baseUrl+"delete.php?id="+sc.delete,
                    method: "get"
                }).then(function(response){
                    alert(response.data);
                },function(error){
                    alert(error.data);
                });
            },
            insert: function(sc){
                $http({
                    url: baseUrl+"insert.php?id="+sc.id+"&fn="+sc.fn+"&ln="+sc.ln+"&g="+sc.g+"&ip="+sc.ip+"&e="+sc.e,
                    method: "get"
                }).then(function(response){
                    alert(response.data);
                },function(error){
                    alert(error.data);
                });
            }
        }
    }
});

myApp.controller("myC", function($scope,myPro){
    myPro.fetch($scope);
    $scope.deleteMe = function(){
        myPro.delete($scope);
        myPro.fetch($scope);
    }
    $scope.insertMe = function(){
        myPro.insert($scope);
    }
});


//http://10.9.2.110/niraj/0710/insert.php?id=1002&fn=kuldeep&ln=pala&g=M&ip=10.9.2.110&e=abc@gmail.com