<?php

    $host = "10.9.2.112";
    $user = "sahil";
    $pass = "123";
    $db = "mydb";

    $conn = mysqli_connect($host,$user,$pass,$db) or die("Connection Failed!!!");

    $query = "SELECT * from emp_data where first_name=".$_GET['search'];

    $result = mysqli_query($conn, $query);
    $data = array();

    echo mysqli_fetch_assoc($result);
    /*while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }
    echo json_encode($data); */