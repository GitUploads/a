<?php

    $host = "10.9.2.112";
    $user = "sahil";
    $pass = "123";
    $db = "mydb";

    $conn = mysqli_connect($host,$user,$pass,$db) or die("Connection Failed!!!");

    $query = "SELECT * from emp_data";

    $result = mysqli_query($conn, $query);
    $data = array();
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }
    echo json_encode($data);