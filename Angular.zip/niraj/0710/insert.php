<?php

$host = "10.9.2.112";
$user = "sahil";
$pass = "123";
$db = "mydb";

$conn = mysqli_connect($host,$user,$pass,$db) or die("Connection Failed!!!");
$id = $_GET['id'];
$fn = $_GET['fn'];
$ln = $_GET['ln'];
$e  = $_GET['e'];
$ip = $_GET['ip'];
$g  = $_GET['g'];

$query = "INSERT INTO emp_data (id, first_name, last_name, email, gender, ip_address) 
                    VALUES ('$id', '$fn', '$ln', '$e', '$g', '$ip')";
echo $query;

$result = mysqli_query($conn, $query);

echo "Record with $_GET[id] Inserted Successfully";
