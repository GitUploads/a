var myApp = angular.module("aumodule",[]);

myApp.factory("oddEven", function(){
    var obj = {};

    obj.calc = function(value){
        if(value %2 === 0 ){
            return "Even";
        }else{
            return "Odd";
        }
    }
    return obj;
})

myApp.factory("oddEven2", function(){
    return {
        calc : function(value){
            if(value %2 === 0){
                return "Even";
            }else{
                return "Odd";
            }
        },
        prime : function(value){
            if(value %2 === 0){
                return "Even";
            }else{
                return "Odd";
            }
        },
        first: "niraj"
    }
})

myApp.service("myService", function(){
    this.oddEven = function(value){
        if(value %2 === 0){
            return "Even";
        }else{
            return "Odd";
        }
    }
});
myApp.controller("myC", function($scope,oddEven,oddEven2, myService){
    $scope.btn1 = function(kuldeep){
        $scope.value = oddEven.calc(kuldeep);
    }
    $scope.btn2 = function(krishna){
        $scope.value2 = oddEven2.calc(krishna);
        $scope.value3 = oddEven.first;
    }
    $scope.btn3 = function(parth){
        $scope.value4 = myService.oddEven(parth)
    }
})