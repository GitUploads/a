var myApp = angular.module("myApp",[]);

myApp.controller("myC", function($scope){
    $scope.videos = [{"video": "03-09-2021-Manually Granting Permission to S3 and Uploading the file to it.mp4"},
    {"video": "07-10-2021-Ec2 - Snapshot - EBS backup from One Ec2 to another.mkv"},
    {"video": "08-09-2021-Explaining Versioning in Amazon S3.mp4"},
    {"video": "08-09-2021-Explanation of CORS and Accessing the Data from more than 2 buckets.mp4"},
    {"video": "08-09-2021-Uploading Tic-Tac-Toe to Amazon S3 and making it run.mp4"},
    {"video": "08-10-2021-EFS sharing with multiple instance.mkv"},
    {"video": "13-10-2021-VPC Demo - 1.mkv"},
    {"video": "15-09-2021-Explaining Encryption for Amazon S3.mp4"},
    {"video": "17-09-2021-AWS - S3 - CORS.mp4"},
    {"video": "18-08-2021-Installing XAMPP in Windows EC2.mp4"},
    {"video": "22-09-2021-AWS EBS- Practical -2.mp4"},
    {"video": "22-09-2021-Connecting Ubuntu from Windows.mp4"},
    {"video": "22-10-2021-VPC NAT Gateway.mkv"},
    {"video": "22-10-2021-VPC Peering.mkv"},
    {"video": "23-08-2021-Installing Apache in Linux EC2"},
    {"video": "24-09-2021-EBS Multi Attachment.mp4"},
    {"video": "25-08-2021-EC2-Linux Instance.mp4"},
    {"video": "25-08-2021-EC2 - Windows Instance.mp4"},
    {"video": "25-08-2021-EC2- Windows Instance Ending.mp4"},
    {"video": "25-08-2021-How to SignUp and Login in AWS Educate.mp4"},
    {"video": "25-08-2021-Login to Linux Windows EC2 Example.mp4"},
    {"video": "26-10-2021-VPC EndPoint.mp4"}];
});

/*



*/