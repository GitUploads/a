<?php

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db   = "myDB";

    $conn = mysqli_connect($host, $user, $pass, $db) or die("Error connecting");
    $id = $_GET['id'];
    $query = "SELECT * from COURSES where id = ". $id;

    $result = mysqli_query($conn, $query);

    $data = array();
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }

    echo json_encode($data);