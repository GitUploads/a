<?php

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db   = "myDB";

    $conn = mysqli_connect($host, $user, $pass, $db) or die("Error connecting");
 
    $query = "SELECT * from students_data";

    $result = mysqli_query($conn, $query);

    $data = array();
    $data = [];
    $data['Female'] = 0;
    $data['Male'] = 0;
    $data['Total'] = 0;
    while($row = mysqli_fetch_array($result)){
        $g = $row['gender'];
        switch($g){
            case "Female": 
                $data['Female'] = $data['Female'] + 1;
                $data['Total'] = $data['Total'] + 1;
                break;
            case "Male": 
                $data['Male'] = $data['Male'] + 1;
                $data['Total'] = $data['Total'] + 1;
                break;
        }
    }
    echo json_encode($data);