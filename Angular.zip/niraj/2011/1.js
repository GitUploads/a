var myApp = angular.module("myApp",['ui.router']);
myApp.service("dbData", function($http){
    var obj = {};
    obj.fetch = function(cb){
        $http({
            url: "http://10.9.2.110/niraj/2011/fetchCourses.php" ,
            method: "get"
        }).then(function(r){
            cb(r.data);
        }, function(e){ });
    }
    obj.search = function(uid,cb){
        $http({
            url: "http://10.9.2.110/niraj/2011/search.php" ,
            method: "get",
            params: {id: uid}
        }).then(function(r){
            cb(r.data);
        }, function(e){ });
    }
    obj.fetchStudents = function(cb){
        $http({
            url: "http://10.9.2.110/niraj/2011/fetchStudents.php" ,
            method: "get"
        }).then(function(r){
            cb(r.data);
        }, function(e){ });
    }
    obj.searchStudents = function(cb,studentName){
        $http({
            method: "get",
            url: "http://10.9.2.110/niraj/2011/searchstudents.php",
            params: {name: studentName}
        }).then(function(res){
            cb(res.data)
        }, function(){ })
    }
    obj.calcGender = function(cb){
        $http({
            method: "get",
            url: "http://10.9.2.110/niraj/2011/total.php"
        }).then(function(r){
            cb(r.data);
        }, function(e){})
    }
    return obj;
});
myApp.config(function($stateProvider, $urlMatcherFactoryProvider, $urlRouterProvider){
    //$routeProvider.caseInsensitve(true); for ngRoute
    //$urlMatcherFactoryProvider.caseInsensitive(true); //for ui.router only
    //$urlRouterProvider.otherwise('/');
    $stateProvider
        .state("home",{
            url: "/",
            templateUrl: "home.html",  // College - Front Page... Lorem Ipsum
            controller: "homeController",
            controllerAs: "hcc",
            data: {
                customData1: "I am Custom Data 1 from Home Controller",
                customData2: "I am Custom Data 2 from Home Controller",
            }
        })
        .state("gender",{ //Parent
            url: "/gender",
            templateUrl: "gender.html",
            controller: "calculateGenderController",
            controllerAs: "cgc",
            abstract: true
        })
        .state("gender.students",{ //Child
            url: "/students",
            templateUrl: "students.html", //CRUD - factory
            controller: "studController",
            controllerAs: "sc",
            resolve: {
                studentFetch : function($http){
                    return $http({
                        method: "get",
                        url: "http://10.9.2.110/niraj/2011/fetchStudents.php"
                    }).then(function(r){ 
                        return r.data;
                    }, function(e){ });
                }
            }
        })
        .state("gender.courses",{ //Child
            url: "/courses",
            templateUrl: "courses.html", //CRUD - service
            controller: "coursesController",
            controllerAs : "cc",
            data: {
                customData1: "I am Custom Data 1 from Courses Controller",
                customData2: "I am Custom Data 2 from Courses Controller",
            }
        })
        .state("gender.courseId",{
            url: "/courses/:id",
            templateUrl: "searchCourse.html",
            controller: "searchCourseController",
            controllerAs: "scc"
        })

        .state("404", {
            url: "/404",
            templateUrl: "404.html"
        })
        .state("studentsByName",{
            url: "/studentsSearch/:name?",
            templateUrl: "searchStudents.html",
            controller: "searchStudents",
            controllerAs: "ss"
        })
        // .otherwise({
        //     redirectTo: '/404'
        // })
});
myApp.controller("calculateGenderController", function(dbData){
    var mca = this;
    dbData.calcGender(function(data){
        mca.data = data;
    })
});
myApp.controller("searchCourseController", function($stateParams,dbData){
    this.id = $stateParams.id;
    var scc = this;
    dbData.search(this.id, function(data){
        scc.data = data;
    });
})

myApp.controller("homeController", function($state){
    this.customD1 = $state.current.data.customData1;
    this.customD2 = $state.current.data.customData2;
    this.customD3 = $state.get("courses").data.customData1
    this.customD4 = $state.get("courses").data.customData2
})

myApp.controller("searchStudents", function(dbData,$stateParams, $http){
    var vm = this;
    alert("stateparams: "+$stateParams.name);
    if($stateParams.name == null || $stateParams.name == "undefined"){
        dbData.fetchStudents(function(data){
            vm.students = data;
        });
    }
    else if($stateParams.name != "undefined"){
        dbData.searchStudents(function(data){
            vm.students = data;
        }, $stateParams.name)
    }

});
homeController = function($scope){
    $scope.data = "Hello World";
}
studentController = function(studentFetch, $state){
    var vm = this;
    //cut 
    vm.students = studentFetch;
    vm.searchMe = function(){
        //alert("I am getting displayed " +vm.name);
        //$location.url("/studentsSearch/" + vm.name)
        $state.go("studentsByName",{name: vm.name});
    }
}
myApp.controller("coursesController", function($scope,dbData){
    var cc = this;
    $scope.$on("$routeChangeStart",function(event,next,previous){
        console.log(next);
        if(!confirm("Redirecting you to new page!!!: " +next)){
            event.preventDefault();
        }
    });
    $scope.visible = false;
    $scope.$on("$routeChangeStart", function(event,next,previous){
        $scope.visible = true;
    });
    $scope.$on("$routeChangeSuccess", function(event,next,previous){
        $scope.visible = false;
    });

    // var abc = function(){
    //     $scope.$on("$routeChangeStart",function(event,next,previous){
    //         console.log("$routeChangeStart Callled!!!");
    //     });
    //     $scope.$on("$locationChangeStart",function(event,next,previous){
    //         console.log("$locationChangeStart Callled!!!");
    //     });
    //     $scope.$on("$routeChangeSuccess",function(event,next,previous){
    //         console.log("$routeChangeSuccess Callled!!!");
    //     });
    //     $scope.$on("$locationChangeSuccess",function(event,next,previous){
    //         console.log("$locationChangeSuccess Callled!!!");
    //     });
    //}
    dbData.fetch(function(data){
        cc.courses = data;
    });
})
myApp.controller("myC", homeController);

myApp.controller("studController", studentController);
