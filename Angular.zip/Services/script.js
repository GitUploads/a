var MyApp = angular.module("myApp",[]);

MyApp.service("myDb",function($http){
    this.insert = function(sc){
        $http({
            method: "get",
            url: "http://localhost/AngularJS/dbConnect/Services/insert.php?name="+sc.name+"&dep="+sc.dep+"&salary="+sc.salary
            //url: "http://localhost/DataBase%20Connect%20Using%20Angular/insert.php?name="+sc.name+"&department="+sc.dep+"&salary="+sc.salary,
        }).then(function(response){
            alert(response.data);
        },function(error){
            alert(error.data);
        });
    }
    this.display = function(sc){
        $http({
            url:"http://localhost/AngularJS/dbConnect/Services/display.php",
            method: "get"
        }).then(function(response){
            sc.data=response.data;
        },function(arror){
            alert(arror.data);
        });
    }
    this.update = function(sc){
        $http({
            url:"http://localhost/AngularJS/dbConnect/Services/update.php?id="+sc.ids+"&name="+sc.names+"&dep="+sc.deps+"&salary="+sc.salarys,
            method: "get"
        }).then(function(response){
            alert("Record Updated.");
        },function(error){
            alert("Somthing Wants Wrong");
        });
    }
});

MyApp.controller("myController",function($scope,myDb){
    $scope.showMe =false
    $scope.insert = function(){
        myDb.insert($scope);
        clear();
    }
    $scope.display = function(){
        myDb.display($scope);
    }
    $scope.update = function(){
        $scope.showMe = false;
        myDb.update($scope)
    }
    $scope.editMe = function(id,name,dep,salary){
        $scope.showMe = true;
        $scope.ids = id; 
        $scope.names = name;
        $scope.deps = dep;
        $scope.salarys = salary; 
    }
    function clear(){
        $scope.name = null;
        $scope.dep= null;
        $scope.salary=null;
    }

});
