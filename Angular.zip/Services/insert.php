<?php

$host = "localhost";
$user = "root";
$pss = "";
$db = "angular";

$name = $_GET['name'];
$dep = $_GET['dep'];
$salary = $_GET['salary'];


$conn = mysqli_connect($host,$user,$pss,$db) or die ("Connecton Faild...");

$query = "INSERT INTO emp (name,department,salary) VALUES ('$name','$dep',$salary) ";

$result = mysqli_query($conn,$query);

echo "Record Insert Successfuly";

?>