<?php
    $name = $_GET['names'];
    $dep = $_GET['deps'];
    $salary = $_GET['salarys'];
    $id = $_GET['ids'];

    $conn = mysqli_connect("localhost","root","","angular") or die ("Connection Faild...!!");

    $query = "UPDATE emp SET name = '$name', department = '$dep', salary = '$salary' WHERE id = '$id'";
   
    echo $query;
    
    $result = mysqli_query($conn,$query)
?>