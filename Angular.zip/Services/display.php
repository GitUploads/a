<?php
  
    $conn = mysqli_connect("localhost","root","","angular") or die ("Connection Faild...");
    $query = "SELECT * FROM emp";

    $result = mysqli_query($conn,$query);

    $data = array();
    
    while($row = mysqli_fetch_assoc($result)){
        $data[] = $row;
    }

    echo json_encode($data);


?>